-- Drop old tables
DROP TABLE IF EXISTS "reviews" CASCADE;
DROP TABLE IF EXISTS "order_items" CASCADE;
DROP TABLE IF EXISTS "orders" CASCADE;
DROP TABLE IF EXISTS "businesses" CASCADE;
DROP TABLE IF EXISTS "users" CASCADE;
DROP TABLE IF EXISTS "categories" CASCADE;
DROP TYPE IF EXISTS "order_status" CASCADE;
DROP TYPE IF EXISTS "user_role" CASCADE;

-- New enums
CREATE TYPE "order_status" AS ENUM ('pending', 'confirmed', 'in_production', 'shipped', 'delivered', 'cancelled');
CREATE TYPE "shirt_size" AS ENUM ('XS', 'S', 'M', 'L', 'XL', 'XXL');
CREATE TYPE "shirt_color" AS ENUM ('black', 'white', 'grey', 'navy', 'forest');

-- Products (catalog drops)
CREATE TABLE IF NOT EXISTS "products" (
  "id" serial PRIMARY KEY,
  "name" varchar(200) NOT NULL,
  "description" text,
  "price" decimal(10, 2) NOT NULL,
  "image_url" text,
  "tag" varchar(50),
  "is_available" boolean DEFAULT true,
  "created_at" timestamp DEFAULT now() NOT NULL
);

-- Custom shirt orders
CREATE TABLE IF NOT EXISTS "custom_orders" (
  "id" serial PRIMARY KEY,
  "customer_name" varchar(150) NOT NULL,
  "customer_email" varchar(255) NOT NULL,
  "customer_phone" varchar(30),
  "shirt_color" "shirt_color" NOT NULL,
  "shirt_size" "shirt_size" NOT NULL,
  "quantity" integer DEFAULT 1 NOT NULL,
  "design_text" text,
  "design_notes" text,
  "print_location" varchar(50),
  "design_file_url" text,
  "total_amount" decimal(10, 2) NOT NULL,
  "status" "order_status" DEFAULT 'pending' NOT NULL,
  "created_at" timestamp DEFAULT now() NOT NULL
);

-- Catalog orders
CREATE TABLE IF NOT EXISTS "catalog_orders" (
  "id" serial PRIMARY KEY,
  "customer_name" varchar(150) NOT NULL,
  "customer_email" varchar(255) NOT NULL,
  "customer_phone" varchar(30),
  "shirt_size" "shirt_size" NOT NULL,
  "quantity" integer DEFAULT 1 NOT NULL,
  "total_amount" decimal(10, 2) NOT NULL,
  "status" "order_status" DEFAULT 'pending' NOT NULL,
  "product_id" integer REFERENCES "products"("id") ON DELETE SET NULL,
  "notes" text,
  "created_at" timestamp DEFAULT now() NOT NULL
);

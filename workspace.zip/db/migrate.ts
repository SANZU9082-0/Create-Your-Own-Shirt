import 'dotenv/config'
import postgres from 'postgres'
import { readFileSync } from 'fs'

async function migrate() {
  const sql = readFileSync('./drizzle/0001_clothing_brand.sql', 'utf8')
  const client = postgres(process.env.DATABASE_URL!, { prepare: false })
  await client.unsafe(sql)
  console.log('Migration applied!')
  await client.end()
}

migrate().catch((e) => { console.error(e); process.exit(1) })

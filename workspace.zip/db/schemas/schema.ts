import {
  pgTable,
  serial,
  text,
  varchar,
  decimal,
  integer,
  boolean,
  timestamp,
  pgEnum,
  jsonb,
} from 'drizzle-orm/pg-core'
import { relations } from 'drizzle-orm'

// Enums
export const orderStatusEnum = pgEnum('order_status', [
  'pending',
  'confirmed',
  'in_production',
  'shipped',
  'delivered',
  'cancelled',
])

export const shirtSizeEnum = pgEnum('shirt_size', ['XS', 'S', 'M', 'L', 'XL', 'XXL'])
export const shirtColorEnum = pgEnum('shirt_color', ['black', 'white', 'grey', 'navy', 'forest'])

// Catalog products (pre-made drops)
export const products = pgTable('products', {
  id: serial('id').primaryKey(),
  name: varchar('name', { length: 200 }).notNull(),
  description: text('description'),
  price: decimal('price', { precision: 10, scale: 2 }).notNull(),
  imageUrl: text('image_url'),
  tag: varchar('tag', { length: 50 }), // e.g. "NEW DROP", "LIMITED"
  isAvailable: boolean('is_available').default(true),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

// Custom shirt orders
export const customOrders = pgTable('custom_orders', {
  id: serial('id').primaryKey(),
  // Customer info
  customerName: varchar('customer_name', { length: 150 }).notNull(),
  customerEmail: varchar('customer_email', { length: 255 }).notNull(),
  customerPhone: varchar('customer_phone', { length: 30 }),
  // Shirt design choices
  shirtColor: shirtColorEnum('shirt_color').notNull(),
  shirtSize: shirtSizeEnum('shirt_size').notNull(),
  quantity: integer('quantity').notNull().default(1),
  // Design details
  designText: text('design_text'),          // text to print
  designNotes: text('design_notes'),        // extra instructions
  printLocation: varchar('print_location', { length: 50 }), // front / back / left-chest / full
  designFileUrl: text('design_file_url'),   // optional uploaded image URL
  // Pricing
  totalAmount: decimal('total_amount', { precision: 10, scale: 2 }).notNull(),
  // Status
  status: orderStatusEnum('status').default('pending').notNull(),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

// Catalog product orders (pre-made items)
export const catalogOrders = pgTable('catalog_orders', {
  id: serial('id').primaryKey(),
  customerName: varchar('customer_name', { length: 150 }).notNull(),
  customerEmail: varchar('customer_email', { length: 255 }).notNull(),
  customerPhone: varchar('customer_phone', { length: 30 }),
  shirtSize: shirtSizeEnum('shirt_size').notNull(),
  quantity: integer('quantity').notNull().default(1),
  totalAmount: decimal('total_amount', { precision: 10, scale: 2 }).notNull(),
  status: orderStatusEnum('status').default('pending').notNull(),
  productId: integer('product_id').references(() => products.id, { onDelete: 'set null' }),
  notes: text('notes'),
  createdAt: timestamp('created_at').defaultNow().notNull(),
})

// Relations
export const productsRelations = relations(products, ({ many }) => ({
  catalogOrders: many(catalogOrders),
}))

export const catalogOrdersRelations = relations(catalogOrders, ({ one }) => ({
  product: one(products, { fields: [catalogOrders.productId], references: [products.id] }),
}))

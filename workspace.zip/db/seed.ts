import 'dotenv/config'
import postgres from 'postgres'
import { drizzle } from 'drizzle-orm/postgres-js'
import * as schema from './schemas/schema'

const client = postgres(process.env.DATABASE_URL!, { prepare: false })
const db = drizzle(client, { schema })

async function seed() {
  console.log('Seeding clothing catalog...')

  // Clear existing
  await db.delete(schema.products)

  await db.insert(schema.products).values([
    {
      name: 'VLTG CORE TEE',
      description: 'Our signature heavyweight 100% cotton tee. Oversized fit, dropped shoulders. The foundation of every fit.',
      price: '45.00',
      tag: 'BESTSELLER',
    },
    {
      name: 'STATIC NOISE TEE',
      description: 'Distressed graphic front, acid-washed finish. Looks like it already lived a life.',
      price: '55.00',
      tag: 'NEW DROP',
    },
    {
      name: 'BLACKOUT LONG SLEEVE',
      description: 'Heavyweight French terry. Ribbed cuffs, extended hem. All black everything.',
      price: '65.00',
      tag: 'LIMITED',
    },
    {
      name: 'GRUNGE POCKET TEE',
      description: 'Garment-dyed vintage feel with a raw-edge chest pocket. Relaxed mid-weight cut.',
      price: '48.00',
      tag: null,
    },
    {
      name: 'ARCHIVE CREWNECK',
      description: 'Fleece-backed crewneck with embroidered VLTG logo. Built to be lived in.',
      price: '85.00',
      tag: 'NEW DROP',
    },
    {
      name: 'VOID TEE',
      description: 'All-over texture print on heavyweight cotton. No color, maximum texture.',
      price: '58.00',
      tag: 'LIMITED',
    },
  ])

  console.log('Seed complete!')
  await client.end()
}

seed().catch((e) => { console.error(e); process.exit(1) })

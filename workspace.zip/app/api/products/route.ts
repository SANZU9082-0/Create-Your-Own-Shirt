import { NextResponse } from 'next/server'
import { db } from '@/db'
import { products } from '@/db/schemas/schema'
import { eq } from 'drizzle-orm'

export const runtime = 'nodejs'

export async function GET() {
  try {
    const rows = await db.select().from(products).where(eq(products.isAvailable, true))
    return NextResponse.json(rows)
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Failed to fetch products' }, { status: 500 })
  }
}

import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { customOrders } from '@/db/schemas/schema'

export const runtime = 'nodejs'

// Base price per shirt + print cost
const BASE_PRICE = 45
const PRINT_PRICE = 15

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const {
      customerName,
      customerEmail,
      customerPhone,
      shirtColor,
      shirtSize,
      quantity,
      designText,
      designNotes,
      printLocation,
    } = body

    if (!customerName || !customerEmail || !shirtColor || !shirtSize || !quantity) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const qty = Math.max(1, parseInt(quantity))
    const unitPrice = BASE_PRICE + (designText || designNotes ? PRINT_PRICE : 0)
    const totalAmount = (unitPrice * qty).toFixed(2)

    const [order] = await db.insert(customOrders).values({
      customerName,
      customerEmail,
      customerPhone: customerPhone || null,
      shirtColor,
      shirtSize,
      quantity: qty,
      designText: designText || null,
      designNotes: designNotes || null,
      printLocation: printLocation || 'front',
      totalAmount,
      status: 'pending',
    }).returning()

    return NextResponse.json(order, { status: 201 })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Failed to place order' }, { status: 500 })
  }
}

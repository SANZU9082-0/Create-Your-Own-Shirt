import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/db'
import { catalogOrders, products } from '@/db/schemas/schema'
import { eq } from 'drizzle-orm'

export const runtime = 'nodejs'

export async function POST(req: NextRequest) {
  try {
    const body = await req.json()
    const { customerName, customerEmail, customerPhone, productId, shirtSize, quantity, notes } = body

    if (!customerName || !customerEmail || !productId || !shirtSize) {
      return NextResponse.json({ error: 'Missing required fields' }, { status: 400 })
    }

    const [product] = await db.select().from(products).where(eq(products.id, productId)).limit(1)
    if (!product) {
      return NextResponse.json({ error: 'Product not found' }, { status: 404 })
    }

    const qty = Math.max(1, parseInt(quantity) || 1)
    const totalAmount = (parseFloat(product.price) * qty).toFixed(2)

    const [order] = await db.insert(catalogOrders).values({
      customerName,
      customerEmail,
      customerPhone: customerPhone || null,
      productId,
      shirtSize,
      quantity: qty,
      totalAmount,
      notes: notes || null,
      status: 'pending',
    }).returning()

    return NextResponse.json(order, { status: 201 })
  } catch (e) {
    console.error(e)
    return NextResponse.json({ error: 'Failed to place order' }, { status: 500 })
  }
}

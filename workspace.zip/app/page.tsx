'use client'

import { useEffect, useState, useRef } from 'react'
import { ShoppingBag, Zap, ArrowRight, Check, X, Minus, Plus, Star } from 'lucide-react'

// ─── Types ────────────────────────────────────────────────────────────────────
interface Product {
  id: number
  name: string
  description: string | null
  price: string
  tag: string | null
}

const SHIRT_COLORS = [
  { value: 'black', label: 'BLACK', hex: '#0a0a0a', border: '#333' },
  { value: 'white', label: 'WHITE', hex: '#f5f5f5', border: '#888' },
  { value: 'grey', label: 'GREY', hex: '#555', border: '#777' },
  { value: 'navy', label: 'NAVY', hex: '#1a2a4a', border: '#2a3a6a' },
  { value: 'forest', label: 'FOREST', hex: '#1a3a2a', border: '#2a5a3a' },
]

const SIZES = ['XS', 'S', 'M', 'L', 'XL', 'XXL']
const PRINT_LOCATIONS = ['FRONT', 'BACK', 'LEFT CHEST', 'FULL WRAP']

const TICKER_ITEMS = [
  'FREE SHIPPING OVER $100', '•', 'CUSTOM ORDERS 7–14 DAYS', '•',
  'HEAVYWEIGHT 280GSM COTTON', '•', 'LIMITED DROPS WEEKLY', '•',
  'REAL STREETWEAR', '•', 'NO FAST FASHION', '•',
  'FREE SHIPPING OVER $100', '•', 'CUSTOM ORDERS 7–14 DAYS', '•',
  'HEAVYWEIGHT 280GSM COTTON', '•', 'LIMITED DROPS WEEKLY', '•',
  'REAL STREETWEAR', '•', 'NO FAST FASHION', '•',
]

// ─── Shirt SVG Preview ────────────────────────────────────────────────────────
function ShirtPreview({
  color,
  text,
  location,
}: {
  color: string
  text: string
  location: string
}) {
  const col = SHIRT_COLORS.find((c) => c.value === color) || SHIRT_COLORS[0]
  const textY = location === 'BACK' ? 120 : location === 'LEFT CHEST' ? 80 : 100

  return (
    <svg viewBox="0 0 200 220" fill="none" xmlns="http://www.w3.org/2000/svg" className="w-full max-w-[260px] mx-auto drop-shadow-2xl">
      {/* Body */}
      <path
        d="M60 30 L20 70 L40 80 L35 190 L165 190 L160 80 L180 70 L140 30 L120 50 C110 60 90 60 80 50 Z"
        fill={col.hex}
        stroke={col.border}
        strokeWidth="2"
      />
      {/* Collar */}
      <path
        d="M80 50 C90 65 110 65 120 50"
        fill="none"
        stroke={col.border}
        strokeWidth="2"
      />
      {/* Left sleeve */}
      <path d="M60 30 L20 70 L40 80 L55 55 Z" fill={col.hex} stroke={col.border} strokeWidth="1.5" />
      {/* Right sleeve */}
      <path d="M140 30 L180 70 L160 80 L145 55 Z" fill={col.hex} stroke={col.border} strokeWidth="1.5" />
      {/* Design text preview */}
      {text && (
        <text
          x="100"
          y={textY}
          textAnchor="middle"
          fill="#D6FF3A"
          fontSize={text.length > 10 ? '9' : '12'}
          fontFamily="monospace"
          fontWeight="bold"
          letterSpacing="2"
        >
          {text.toUpperCase().slice(0, 18)}
        </text>
      )}
      {/* VLTG placeholder when no text */}
      {!text && (
        <text
          x="100"
          y="105"
          textAnchor="middle"
          fill="rgba(214,255,58,0.25)"
          fontSize="14"
          fontFamily="monospace"
          fontWeight="bold"
          letterSpacing="4"
        >
          VLTG
        </text>
      )}
    </svg>
  )
}

// ─── Product Card ─────────────────────────────────────────────────────────────
function ProductCard({
  product,
  onOrder,
}: {
  product: Product
  onOrder: (product: Product) => void
}) {
  const SHIRT_EMOJIS = ['👕', '🖤', '⚡', '🔥', '💀', '🌑']
  const emoji = SHIRT_EMOJIS[product.id % SHIRT_EMOJIS.length]

  return (
    <div className="border border-[rgba(214,255,58,0.15)] bg-[#0D1110] rounded-xl overflow-hidden card-glow transition-all duration-150 cursor-pointer group"
      onClick={() => onOrder(product)}>
      {/* Image area */}
      <div className="h-52 bg-[#0a0c0b] flex items-center justify-center relative overflow-hidden">
        <div className="text-7xl group-hover:scale-110 transition-transform duration-300">{emoji}</div>
        <div className="absolute inset-0 bg-gradient-to-br from-[rgba(214,255,58,0.03)] to-transparent" />
        {product.tag && (
          <div className="absolute top-3 left-3 bg-[#D6FF3A] text-[#040505] text-[10px] font-mono font-bold px-2 py-1 rounded-full tracking-widest">
            {product.tag}
          </div>
        )}
      </div>
      <div className="p-5">
        <div className="flex items-start justify-between gap-2 mb-2">
          <h3 className="font-bold text-[#F4F8F2] text-sm tracking-widest">{product.name}</h3>
          <span className="text-[#D6FF3A] font-mono font-bold text-sm whitespace-nowrap">${parseFloat(product.price).toFixed(2)}</span>
        </div>
        <p className="text-[#8FA08F] text-xs leading-relaxed mb-4">{product.description}</p>
        <button
          className="w-full py-2 rounded-full border border-[rgba(214,255,58,0.4)] text-[#D6FF3A] text-xs font-mono font-bold tracking-widest hover:bg-[#D6FF3A] hover:text-[#040505] transition-all duration-150"
          onClick={(e) => { e.stopPropagation(); onOrder(product) }}
        >
          ORDER NOW
        </button>
      </div>
    </div>
  )
}

// ─── Modal base ───────────────────────────────────────────────────────────────
function Modal({ open, onClose, children }: { open: boolean; onClose: () => void; children: React.ReactNode }) {
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-end sm:items-center justify-center p-4 bg-black/70 backdrop-blur-sm">
      <div className="bg-[#0D1110] border border-[rgba(214,255,58,0.2)] rounded-2xl w-full max-w-lg max-h-[90vh] overflow-y-auto shadow-2xl">
        <div className="flex justify-end p-4 pb-0">
          <button onClick={onClose} className="text-[#8FA08F] hover:text-[#F4F8F2] transition-colors">
            <X className="w-5 h-5" />
          </button>
        </div>
        {children}
      </div>
    </div>
  )
}

// ─── Catalog Order Modal ──────────────────────────────────────────────────────
function CatalogOrderModal({ product, onClose }: { product: Product | null; onClose: () => void }) {
  const [size, setSize] = useState('M')
  const [qty, setQty] = useState(1)
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [notes, setNotes] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  if (!product) return null

  const total = (parseFloat(product.price) * qty).toFixed(2)

  const handleSubmit = async () => {
    if (!name || !email) return
    setLoading(true)
    try {
      const res = await fetch('/api/orders/catalog', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ customerName: name, customerEmail: email, customerPhone: phone, productId: product.id, shirtSize: size, quantity: qty, notes }),
      })
      if (res.ok) setSuccess(true)
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <Modal open onClose={onClose}>
        <div className="px-6 pb-8 text-center">
          <div className="w-16 h-16 rounded-full bg-[rgba(214,255,58,0.15)] flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-[#D6FF3A]" />
          </div>
          <h3 className="text-xl font-bold text-[#F4F8F2] mb-2">ORDER PLACED</h3>
          <p className="text-[#8FA08F] text-sm mb-1">We received your order for <span className="text-[#D6FF3A]">{product.name}</span>.</p>
          <p className="text-[#8FA08F] text-sm mb-6">Check your email for confirmation.</p>
          <button onClick={onClose} className="bg-[#D6FF3A] text-[#040505] font-bold text-sm px-8 py-3 rounded-full glow-btn transition-all">
            CLOSE
          </button>
        </div>
      </Modal>
    )
  }

  return (
    <Modal open onClose={onClose}>
      <div className="px-6 pb-8">
        <h2 className="text-lg font-bold text-[#F4F8F2] tracking-widest mb-1">{product.name}</h2>
        <p className="text-[#D6FF3A] font-mono text-sm mb-5">${parseFloat(product.price).toFixed(2)} / UNIT</p>

        {/* Size */}
        <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-2">SELECT SIZE</label>
        <div className="flex gap-2 flex-wrap mb-5">
          {SIZES.map((s) => (
            <button key={s} onClick={() => setSize(s)}
              className={`px-3 py-1.5 rounded-full text-xs font-mono font-bold border transition-all ${size === s ? 'bg-[#D6FF3A] text-[#040505] border-[#D6FF3A]' : 'border-[rgba(214,255,58,0.3)] text-[#8FA08F] hover:border-[#D6FF3A]'}`}>
              {s}
            </button>
          ))}
        </div>

        {/* Quantity */}
        <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-2">QUANTITY</label>
        <div className="flex items-center gap-3 mb-5">
          <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-8 h-8 rounded-full border border-[rgba(214,255,58,0.3)] flex items-center justify-center hover:border-[#D6FF3A] transition-all">
            <Minus className="w-3 h-3 text-[#D6FF3A]" />
          </button>
          <span className="font-mono font-bold text-[#F4F8F2] w-6 text-center">{qty}</span>
          <button onClick={() => setQty(qty + 1)} className="w-8 h-8 rounded-full border border-[rgba(214,255,58,0.3)] flex items-center justify-center hover:border-[#D6FF3A] transition-all">
            <Plus className="w-3 h-3 text-[#D6FF3A]" />
          </button>
          <span className="text-[#D6FF3A] font-mono font-bold ml-2">${total}</span>
        </div>

        {/* Customer info */}
        <div className="space-y-3 mb-5">
          {[
            { label: 'FULL NAME *', val: name, set: setName, type: 'text', ph: 'Your name' },
            { label: 'EMAIL *', val: email, set: setEmail, type: 'email', ph: 'your@email.com' },
            { label: 'PHONE', val: phone, set: setPhone, type: 'tel', ph: 'Optional' },
          ].map(({ label, val, set, type, ph }) => (
            <div key={label}>
              <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-1">{label}</label>
              <input
                type={type}
                value={val}
                placeholder={ph}
                onChange={(e) => set(e.target.value)}
                className="w-full bg-[#11161A] border border-[rgba(214,255,58,0.15)] rounded-lg px-3 py-2.5 text-[#F4F8F2] text-sm placeholder-[#5A6B5A] focus:border-[rgba(214,255,58,0.5)] outline-none transition-colors"
              />
            </div>
          ))}
          <div>
            <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-1">NOTES</label>
            <textarea
              value={notes}
              placeholder="Any special requests..."
              onChange={(e) => setNotes(e.target.value)}
              rows={2}
              className="w-full bg-[#11161A] border border-[rgba(214,255,58,0.15)] rounded-lg px-3 py-2.5 text-[#F4F8F2] text-sm placeholder-[#5A6B5A] focus:border-[rgba(214,255,58,0.5)] outline-none transition-colors resize-none"
            />
          </div>
        </div>

        <button
          disabled={!name || !email || loading}
          onClick={handleSubmit}
          className="w-full py-3.5 rounded-full bg-[#D6FF3A] text-[#040505] font-bold tracking-widest text-sm glow-btn transition-all disabled:opacity-40 disabled:cursor-not-allowed"
        >
          {loading ? 'PLACING ORDER...' : `PLACE ORDER · $${total}`}
        </button>
      </div>
    </Modal>
  )
}

// ─── Custom Builder Modal ─────────────────────────────────────────────────────
function CustomBuilderModal({ open, onClose }: { open: boolean; onClose: () => void }) {
  const [step, setStep] = useState(1)
  const [color, setColor] = useState('black')
  const [size, setSize] = useState('M')
  const [qty, setQty] = useState(1)
  const [printLoc, setPrintLoc] = useState('FRONT')
  const [designText, setDesignText] = useState('')
  const [designNotes, setDesignNotes] = useState('')
  const [name, setName] = useState('')
  const [email, setEmail] = useState('')
  const [phone, setPhone] = useState('')
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState(false)

  const BASE = 45
  const PRINT_FEE = 15
  const hasDesign = !!designText || !!designNotes
  const unitPrice = BASE + (hasDesign ? PRINT_FEE : 0)
  const total = (unitPrice * qty).toFixed(2)

  const handleSubmit = async () => {
    if (!name || !email) return
    setLoading(true)
    try {
      const res = await fetch('/api/orders/custom', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          customerName: name, customerEmail: email, customerPhone: phone,
          shirtColor: color, shirtSize: size, quantity: qty,
          designText, designNotes,
          printLocation: printLoc,
        }),
      })
      if (res.ok) setSuccess(true)
    } finally {
      setLoading(false)
    }
  }

  if (success) {
    return (
      <Modal open={open} onClose={onClose}>
        <div className="px-6 pb-8 text-center">
          <div className="w-16 h-16 rounded-full bg-[rgba(214,255,58,0.15)] flex items-center justify-center mx-auto mb-4">
            <Check className="w-8 h-8 text-[#D6FF3A]" />
          </div>
          <h3 className="text-xl font-bold text-[#F4F8F2] mb-2">CUSTOM ORDER PLACED</h3>
          <p className="text-[#8FA08F] text-sm mb-1">We will reach out within 24hrs to confirm your design.</p>
          <p className="text-[#8FA08F] text-sm mb-6">Production takes 7–14 days.</p>
          <button onClick={onClose} className="bg-[#D6FF3A] text-[#040505] font-bold text-sm px-8 py-3 rounded-full glow-btn transition-all">CLOSE</button>
        </div>
      </Modal>
    )
  }

  return (
    <Modal open={open} onClose={onClose}>
      <div className="px-6 pb-8">
        <h2 className="text-lg font-bold text-[#F4F8F2] tracking-widest mb-1">BUILD YOUR SHIRT</h2>
        <p className="text-[#8FA08F] text-xs font-mono mb-5">
          BASE $45 {hasDesign ? '+ $15 PRINT' : ''} · STEP {step}/3
        </p>

        {/* Step progress */}
        <div className="flex gap-1 mb-6">
          {[1, 2, 3].map((s) => (
            <div key={s} className={`flex-1 h-1 rounded-full transition-all ${s <= step ? 'bg-[#D6FF3A]' : 'bg-[#11161A]'}`} />
          ))}
        </div>

        {step === 1 && (
          <div>
            {/* Shirt preview */}
            <ShirtPreview color={color} text={designText} location={printLoc} />

            {/* Color */}
            <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-2 mt-4">SHIRT COLOR</label>
            <div className="flex gap-3 flex-wrap mb-5">
              {SHIRT_COLORS.map((c) => (
                <button key={c.value} onClick={() => setColor(c.value)}
                  className={`flex flex-col items-center gap-1 group transition-all`}>
                  <div className={`w-9 h-9 rounded-full border-2 transition-all ${color === c.value ? 'border-[#D6FF3A] scale-110' : 'border-transparent hover:border-[rgba(214,255,58,0.4)]'}`}
                    style={{ backgroundColor: c.hex }} />
                  <span className={`text-[9px] font-mono ${color === c.value ? 'text-[#D6FF3A]' : 'text-[#5A6B5A]'}`}>{c.label}</span>
                </button>
              ))}
            </div>

            {/* Size */}
            <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-2">SIZE</label>
            <div className="flex gap-2 flex-wrap mb-5">
              {SIZES.map((s) => (
                <button key={s} onClick={() => setSize(s)}
                  className={`px-3 py-1.5 rounded-full text-xs font-mono font-bold border transition-all ${size === s ? 'bg-[#D6FF3A] text-[#040505] border-[#D6FF3A]' : 'border-[rgba(214,255,58,0.3)] text-[#8FA08F] hover:border-[#D6FF3A]'}`}>
                  {s}
                </button>
              ))}
            </div>

            {/* Quantity */}
            <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-2">QUANTITY</label>
            <div className="flex items-center gap-3 mb-6">
              <button onClick={() => setQty(Math.max(1, qty - 1))} className="w-8 h-8 rounded-full border border-[rgba(214,255,58,0.3)] flex items-center justify-center hover:border-[#D6FF3A] transition-all">
                <Minus className="w-3 h-3 text-[#D6FF3A]" />
              </button>
              <span className="font-mono font-bold text-[#F4F8F2] w-6 text-center">{qty}</span>
              <button onClick={() => setQty(qty + 1)} className="w-8 h-8 rounded-full border border-[rgba(214,255,58,0.3)] flex items-center justify-center hover:border-[#D6FF3A] transition-all">
                <Plus className="w-3 h-3 text-[#D6FF3A]" />
              </button>
            </div>

            <button onClick={() => setStep(2)}
              className="w-full py-3.5 rounded-full bg-[#D6FF3A] text-[#040505] font-bold tracking-widest text-sm glow-btn transition-all">
              NEXT: DESIGN →
            </button>
          </div>
        )}

        {step === 2 && (
          <div>
            <ShirtPreview color={color} text={designText} location={printLoc} />

            {/* Print location */}
            <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-2 mt-4">PRINT LOCATION</label>
            <div className="flex gap-2 flex-wrap mb-5">
              {PRINT_LOCATIONS.map((loc) => (
                <button key={loc} onClick={() => setPrintLoc(loc)}
                  className={`px-3 py-1.5 rounded-full text-xs font-mono font-bold border transition-all ${printLoc === loc ? 'bg-[#D6FF3A] text-[#040505] border-[#D6FF3A]' : 'border-[rgba(214,255,58,0.3)] text-[#8FA08F] hover:border-[#D6FF3A]'}`}>
                  {loc}
                </button>
              ))}
            </div>

            {/* Design text */}
            <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-1">DESIGN TEXT (OPTIONAL)</label>
            <p className="text-[9px] text-[#5A6B5A] font-mono mb-2">+$15 PRINT FEE</p>
            <input
              type="text"
              value={designText}
              placeholder="e.g. YOUR NAME, LOGO TEXT..."
              onChange={(e) => setDesignText(e.target.value)}
              maxLength={20}
              className="w-full bg-[#11161A] border border-[rgba(214,255,58,0.15)] rounded-lg px-3 py-2.5 text-[#F4F8F2] text-sm placeholder-[#5A6B5A] focus:border-[rgba(214,255,58,0.5)] outline-none transition-colors mb-3"
            />

            <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-1">DESIGN NOTES</label>
            <textarea
              value={designNotes}
              placeholder="Describe your design idea, colors, style..."
              onChange={(e) => setDesignNotes(e.target.value)}
              rows={3}
              className="w-full bg-[#11161A] border border-[rgba(214,255,58,0.15)] rounded-lg px-3 py-2.5 text-[#F4F8F2] text-sm placeholder-[#5A6B5A] focus:border-[rgba(214,255,58,0.5)] outline-none transition-colors resize-none mb-5"
            />

            <div className="flex gap-3">
              <button onClick={() => setStep(1)}
                className="flex-1 py-3.5 rounded-full border border-[rgba(214,255,58,0.3)] text-[#D6FF3A] font-bold tracking-widest text-sm hover:border-[#D6FF3A] transition-all">
                ← BACK
              </button>
              <button onClick={() => setStep(3)}
                className="flex-1 py-3.5 rounded-full bg-[#D6FF3A] text-[#040505] font-bold tracking-widest text-sm glow-btn transition-all">
                NEXT →
              </button>
            </div>
          </div>
        )}

        {step === 3 && (
          <div>
            {/* Order summary */}
            <div className="bg-[#11161A] rounded-xl p-4 mb-5 border border-[rgba(214,255,58,0.1)]">
              <p className="text-[10px] font-mono text-[#8FA08F] tracking-widest mb-3">ORDER SUMMARY</p>
              {[
                ['COLOR', SHIRT_COLORS.find(c => c.value === color)?.label || color],
                ['SIZE', size],
                ['QTY', String(qty)],
                ['PRINT LOCATION', printLoc],
                ['DESIGN TEXT', designText || 'NONE'],
                ['BASE PRICE', `$${BASE}`],
                ...(hasDesign ? [['PRINT FEE', `$${PRINT_FEE}`]] : []),
                ['TOTAL', `$${total}`],
              ].map(([k, v]) => (
                <div key={k} className="flex justify-between text-xs mb-1.5">
                  <span className="text-[#5A6B5A] font-mono">{k}</span>
                  <span className={k === 'TOTAL' ? 'text-[#D6FF3A] font-bold font-mono' : 'text-[#F4F8F2] font-mono'}>{v}</span>
                </div>
              ))}
            </div>

            <div className="space-y-3 mb-5">
              {[
                { label: 'FULL NAME *', val: name, set: setName, type: 'text', ph: 'Your name' },
                { label: 'EMAIL *', val: email, set: setEmail, type: 'email', ph: 'your@email.com' },
                { label: 'PHONE', val: phone, set: setPhone, type: 'tel', ph: 'Optional' },
              ].map(({ label, val, set, type, ph }) => (
                <div key={label}>
                  <label className="block text-[10px] font-mono text-[#8FA08F] tracking-widest mb-1">{label}</label>
                  <input
                    type={type}
                    value={val}
                    placeholder={ph}
                    onChange={(e) => set(e.target.value)}
                    className="w-full bg-[#11161A] border border-[rgba(214,255,58,0.15)] rounded-lg px-3 py-2.5 text-[#F4F8F2] text-sm placeholder-[#5A6B5A] focus:border-[rgba(214,255,58,0.5)] outline-none transition-colors"
                  />
                </div>
              ))}
            </div>

            <div className="flex gap-3">
              <button onClick={() => setStep(2)}
                className="flex-1 py-3.5 rounded-full border border-[rgba(214,255,58,0.3)] text-[#D6FF3A] font-bold tracking-widest text-sm hover:border-[#D6FF3A] transition-all">
                ← BACK
              </button>
              <button
                disabled={!name || !email || loading}
                onClick={handleSubmit}
                className="flex-1 py-3.5 rounded-full bg-[#D6FF3A] text-[#040505] font-bold tracking-widest text-sm glow-btn transition-all disabled:opacity-40 disabled:cursor-not-allowed"
              >
                {loading ? 'SENDING...' : `CONFIRM $${total}`}
              </button>
            </div>
          </div>
        )}
      </div>
    </Modal>
  )
}

// ─── Main Page ────────────────────────────────────────────────────────────────
export default function HomePage() {
  const [products, setProducts] = useState<Product[]>([])
  const [selectedProduct, setSelectedProduct] = useState<Product | null>(null)
  const [showCustomBuilder, setShowCustomBuilder] = useState(false)
  const catalogRef = useRef<HTMLDivElement>(null)

  useEffect(() => {
    fetch('/api/products').then((r) => r.json()).then((d) => setProducts(Array.isArray(d) ? d : [])).catch(() => {})
  }, [])

  return (
    <div className="min-h-screen bg-[#040505] text-[#F4F8F2]" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>

      {/* ── Nav ─────────────────────────────────────────────────────────── */}
      <nav className="fixed top-0 left-0 right-0 z-40 bg-[rgba(4,5,5,0.9)] backdrop-blur-md border-b border-[rgba(214,255,58,0.1)]">
        <div className="max-w-6xl mx-auto px-6 h-14 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Zap className="w-5 h-5 text-[#D6FF3A]" />
            <span className="font-black text-lg tracking-[0.2em]" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>VLTG</span>
          </div>
          <div className="hidden md:flex items-center gap-6">
            {['DROPS', 'CUSTOM', 'ABOUT'].map((item) => (
              <button key={item}
                onClick={() => item === 'CUSTOM' ? setShowCustomBuilder(true) : catalogRef.current?.scrollIntoView({ behavior: 'smooth' })}
                className="text-[11px] font-mono text-[#8FA08F] hover:text-[#D6FF3A] tracking-widest transition-colors">
                {item}
              </button>
            ))}
          </div>
          <button
            onClick={() => setShowCustomBuilder(true)}
            className="bg-[#D6FF3A] text-[#040505] text-xs font-bold font-mono px-5 py-2 rounded-full glow-btn tracking-widest transition-all"
          >
            BUILD CUSTOM
          </button>
        </div>
      </nav>

      {/* ── Ticker Bar ──────────────────────────────────────────────────── */}
      <div className="pt-14">
        <div className="bg-[rgba(214,255,58,0.07)] border-b border-[rgba(214,255,58,0.15)] overflow-hidden py-2">
          <div className="animate-ticker">
            {TICKER_ITEMS.map((item, i) => (
              <span key={i} className={`mx-4 text-[11px] font-mono tracking-widest ${item === '•' ? 'text-[rgba(214,255,58,0.3)]' : 'text-[#D6FF3A]'}`}>
                {item}
              </span>
            ))}
          </div>
        </div>
      </div>

      {/* ── Hero ────────────────────────────────────────────────────────── */}
      <section className="relative min-h-[88vh] flex items-center justify-center overflow-hidden">
        {/* Background glow */}
        <div className="absolute inset-0 bg-gradient-radial from-[rgba(214,255,58,0.08)] via-transparent to-transparent" style={{ background: 'radial-gradient(circle at 40% 50%, rgba(214,255,58,0.1), transparent 65%)' }} />
        <div className="absolute inset-0 bg-[url('data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iNjAiIGhlaWdodD0iNjAiIHZpZXdCb3g9IjAgMCA2MCA2MCIgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIj48ZyBmaWxsPSJub25lIiBmaWxsLXJ1bGU9ImV2ZW5vZGQiPjxwYXRoIGQ9Ik0wIDBoNjB2NjBIMHoiLz48cGF0aCBkPSJNNjAgMEgwdjYwaDYwVjB6TTEgMWg1OHY1OEgxVjF6IiBmaWxsPSJyZ2JhKDIxNCwyNTUsNTgsMC4wMykiLz48L2c+PC9zdmc+')] opacity-30" />

        <div className="relative z-10 max-w-6xl mx-auto px-6 grid md:grid-cols-2 gap-12 items-center py-16">
          {/* Left: text */}
          <div>
            <div className="inline-flex items-center gap-2 bg-[rgba(214,255,58,0.1)] border border-[rgba(214,255,58,0.3)] rounded-full px-4 py-1.5 mb-6">
              <span className="w-2 h-2 rounded-full bg-[#D6FF3A] animate-pulse-glow" />
              <span className="text-[11px] font-mono text-[#D6FF3A] tracking-widest">NEW DROPS AVAILABLE</span>
            </div>

            <h1 className="text-6xl md:text-7xl font-black leading-[0.9] tracking-tight mb-6" style={{ fontFamily: 'Space Grotesk, sans-serif' }}>
              WEAR<br />
              <span className="text-[#D6FF3A]">YOUR</span><br />
              VISION
            </h1>

            <p className="text-[#8FA08F] text-base leading-relaxed mb-8 max-w-md">
              Custom streetwear built different. Design your own shirt — choose the color, drop your text, pick the placement. Real heavyweight cotton. No limits.
            </p>

            <div className="flex flex-wrap gap-4">
              <button
                onClick={() => setShowCustomBuilder(true)}
                className="flex items-center gap-2 bg-[#D6FF3A] text-[#040505] font-black text-sm px-8 py-4 rounded-full glow-btn tracking-widest transition-all"
              >
                <ShoppingBag className="w-4 h-4" />
                BUILD CUSTOM SHIRT
              </button>
              <button
                onClick={() => catalogRef.current?.scrollIntoView({ behavior: 'smooth' })}
                className="flex items-center gap-2 border border-[rgba(214,255,58,0.4)] text-[#D6FF3A] font-bold text-sm px-8 py-4 rounded-full hover:border-[#D6FF3A] transition-all"
              >
                SHOP DROPS <ArrowRight className="w-4 h-4" />
              </button>
            </div>

            {/* Stats */}
            <div className="flex gap-8 mt-10">
              {[['280GSM', 'HEAVYWEIGHT'], ['7–14D', 'PRODUCTION'], ['100%', 'COTTON']].map(([num, label]) => (
                <div key={label}>
                  <p className="text-[#D6FF3A] font-mono font-bold text-xl">{num}</p>
                  <p className="text-[#5A6B5A] font-mono text-[10px] tracking-widest">{label}</p>
                </div>
              ))}
            </div>
          </div>

          {/* Right: shirt preview */}
          <div className="flex flex-col items-center">
            <div className="relative">
              <div className="absolute inset-0 bg-[rgba(214,255,58,0.05)] rounded-full blur-3xl scale-110" />
              <ShirtPreview color="black" text="VLTG APPAREL" location="FRONT" />
            </div>
            <div className="flex gap-3 mt-4">
              {SHIRT_COLORS.map((c) => (
                <div key={c.value}
                  className="w-5 h-5 rounded-full border border-[rgba(214,255,58,0.2)] cursor-pointer hover:border-[#D6FF3A] hover:scale-125 transition-all"
                  style={{ backgroundColor: c.hex }} />
              ))}
            </div>
            <p className="text-[#5A6B5A] font-mono text-[10px] mt-2 tracking-widest">5 COLORWAYS</p>
          </div>
        </div>
      </section>

      {/* ── Custom Build CTA Banner ──────────────────────────────────────── */}
      <section className="bg-[#D6FF3A] py-12 px-6">
        <div className="max-w-5xl mx-auto flex flex-col md:flex-row items-center justify-between gap-6">
          <div>
            <p className="text-[10px] font-mono text-[rgba(4,5,5,0.5)] tracking-widest mb-1">CUSTOM ORDER</p>
            <h2 className="text-3xl font-black text-[#040505] tracking-tight">DESIGN IT YOUR WAY</h2>
            <p className="text-[rgba(4,5,5,0.6)] text-sm mt-1">From $45 + $15 print · Any text · Any placement · 5 colors</p>
          </div>
          <button
            onClick={() => setShowCustomBuilder(true)}
            className="flex items-center gap-2 bg-[#040505] text-[#D6FF3A] font-black text-sm px-8 py-4 rounded-full transition-all hover:bg-[#0D1110] whitespace-nowrap tracking-widest"
          >
            <Zap className="w-4 h-4" />
            START BUILDING
          </button>
        </div>
      </section>

      {/* ── Catalog ──────────────────────────────────────────────────────── */}
      <section ref={catalogRef} className="py-20 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="flex items-end justify-between mb-10">
            <div>
              <p className="text-[10px] font-mono text-[#D6FF3A] tracking-widest mb-2">LATEST DROPS</p>
              <h2 className="text-4xl font-black tracking-tight">THE CATALOG</h2>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-2 h-2 rounded-full bg-[#37F0C2]" />
              <span className="text-[11px] font-mono text-[#8FA08F] tracking-widest">{products.length} IN STOCK</span>
            </div>
          </div>

          {products.length === 0 ? (
            <div className="text-center py-20 text-[#5A6B5A]">
              <p className="text-4xl mb-4">🖤</p>
              <p className="font-mono tracking-widest">LOADING DROPS...</p>
            </div>
          ) : (
            <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
              {products.map((p) => (
                <ProductCard key={p.id} product={p} onOrder={setSelectedProduct} />
              ))}
            </div>
          )}
        </div>
      </section>

      {/* ── Process ──────────────────────────────────────────────────────── */}
      <section className="py-20 px-6 border-t border-[rgba(214,255,58,0.08)]">
        <div className="max-w-5xl mx-auto">
          <p className="text-[10px] font-mono text-[#D6FF3A] tracking-widest mb-2">HOW IT WORKS</p>
          <h2 className="text-4xl font-black tracking-tight mb-12">SIMPLE PROCESS</h2>
          <div className="grid md:grid-cols-4 gap-6">
            {[
              { step: '01', title: 'CHOOSE', desc: 'Pick from our catalog or start a fully custom build' },
              { step: '02', title: 'DESIGN', desc: 'Select color, size, add your text and placement' },
              { step: '03', title: 'ORDER', desc: 'Submit your info and we confirm within 24hrs' },
              { step: '04', title: 'RECEIVE', desc: '7–14 day production, shipped straight to you' },
            ].map(({ step, title, desc }) => (
              <div key={step} className="border border-[rgba(214,255,58,0.1)] rounded-xl p-5 bg-[#0D1110]">
                <p className="text-[#D6FF3A] font-mono font-bold text-2xl mb-3">{step}</p>
                <h3 className="font-bold tracking-widest text-sm mb-2">{title}</h3>
                <p className="text-[#8FA08F] text-xs leading-relaxed">{desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── Footer ───────────────────────────────────────────────────────── */}
      <footer className="border-t border-[rgba(214,255,58,0.1)] py-10 px-6">
        <div className="max-w-6xl mx-auto flex flex-col md:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Zap className="w-4 h-4 text-[#D6FF3A]" />
            <span className="font-black tracking-[0.3em] text-sm">VLTG APPAREL</span>
          </div>
          <p className="text-[#5A6B5A] font-mono text-[11px] tracking-widest">
            © {new Date().getFullYear()} VLTG APPAREL · REAL STREETWEAR
          </p>
          <button onClick={() => setShowCustomBuilder(true)}
            className="text-[11px] font-mono text-[#D6FF3A] tracking-widest hover:underline">
            BUILD CUSTOM →
          </button>
        </div>
      </footer>

      {/* ── Modals ───────────────────────────────────────────────────────── */}
      <CatalogOrderModal product={selectedProduct} onClose={() => setSelectedProduct(null)} />
      <CustomBuilderModal open={showCustomBuilder} onClose={() => setShowCustomBuilder(false)} />
    </div>
  )
}
